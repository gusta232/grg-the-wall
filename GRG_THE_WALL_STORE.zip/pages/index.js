import React from "react";
import GRGTheWallStore from "../components/GRGTheWallStore";

export default function Home() {
  return <GRGTheWallStore />;
}
